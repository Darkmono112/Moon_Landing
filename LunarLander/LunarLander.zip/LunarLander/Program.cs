﻿
using var game = new LunarLander.LunarLander();
game.Run();
