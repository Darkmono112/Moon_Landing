﻿namespace CS5410
{
    public enum GameStateEnum
    {
        MainMenu,
        GamePlay,
        HighScores,
        Help,
        Controls,
        About,
        Exit
    }
}
